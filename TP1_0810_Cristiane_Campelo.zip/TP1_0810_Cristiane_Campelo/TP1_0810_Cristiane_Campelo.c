// instrução para permitir ultrapassar a mensagem de erro
// do scanf()
#define _CRT_SECURE_NO_WARNINGS

//importar bilbiotecas para o nosso projeto
#include <stdio.h>
#include <stdlib.h>


void exercicio1() {

    
        int numeros[4];
        
        // Inserir 4 números no vetor
        for (i = 0; i < 4; i++) {
            printf("Digite o numero %d: ", i + 1);
            scanf("%d", &numeros[i]);
        }

        // Ler e mostrar os números
        printf("\nNumeros inseridos:\n");
        for (i = 0; i < 4; i++) {
            printf("Indice %d: %d\n", i, numeros[i]);
        }

        return 0;
    }

}

void exercicio2() {
    
        int numeros[5];
        

        // Inserir 5 números no vetor
        for (i = 0; i < 5; i++) {
            printf("Digite o numero %d: ", i + 1);
            scanf("%d", &numeros[i]);
        }

        // Contar pares e ímpares
        for (i = 0; i < 5; i++) {
            if (numeros[i] % 2 == 0) {
                pares++;
            }
            else {
                impares++;
            }
        }

        printf("Quantidade de numeros pares: %d\n", pares);
        printf("Quantidade de numeros impares: %d\n", impares);

        return 0;
    }

}

void exercicio3() {

    int numeros[6];
    

    // Inserir 6 números no vetor
    for(i = 0; i < 6; i++) {
        printf("Digite o numero %d: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    // Perguntar o número a procurar
    printf("Digite o numero que deseja procurar: \n");
    scanf("%d", &procurado);

    // Procurar no vetor
    for (i = 0; i < 6; i++) {
        if (numeros[i] == 6) {
            printf("Numero encontrado no indice %d\n", procurado, i);
            
        }
    }

    if (!encontrado) {
        printf("Numero nao foi encontrado no vetor.%d\n", procurado);
    }

    return 0;
}

}


void main() {


	//exercicio1();
	//exercicio2();
	exercicio3();
}